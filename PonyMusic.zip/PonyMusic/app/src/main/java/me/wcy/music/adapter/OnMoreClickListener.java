package me.wcy.music.adapter;

/**
 * 音乐列表“更多”按钮监听器
 * Created by hzwangchenyan on 2015/12/17.
 */
public interface OnMoreClickListener {
    void onMoreClick(int position);
}
