package me.wcy.music.enums;

/**
 * 加载状态
 * Created by wcy on 2016/1/3.
 */
public enum LoadStateEnum {
    LOADING,// 加载中
    LOAD_SUCCESS,// 加载成功
    LOAD_FAIL// 加载失败
}
