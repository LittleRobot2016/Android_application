package me.wcy.music.utils;

/**
 * Actions
 * Created by hzwangchenyan on 2016/1/22.
 */
public class Actions {
    public static final String ACTION_MEDIA_PLAY_PAUSE = "me.wcy.music.ACTION_MEDIA_PLAY_PAUSE";
    public static final String ACTION_MEDIA_NEXT = "me.wcy.music.ACTION_MEDIA_NEXT";
    public static final String ACTION_MEDIA_PREVIOUS = "me.wcy.music.ACTION_MEDIA_PREVIOUS";
    public static final String VOLUME_CHANGED_ACTION = "android.media.VOLUME_CHANGED_ACTION";
}
