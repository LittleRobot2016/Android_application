package me.wcy.music.widget;

/**
 * 自动加载更多ListView通知事件
 * Created by hzwangchenyan on 2016/1/7.
 */
public interface OnLoadListener {
    void onLoad();
}
