package me.wcy.music.utils;

/**
 * Extras
 * Created by hzwangchenyan on 2015/12/25.
 */
public class Extras {
    public static final String MUSIC_LIST_TYPE = "music_list_type";
    public static final String TING_UID = "ting_uid";
    public static final String FROM_NOTIFICATION = "from_notification";
}
